public class FlowerTile extends PictureTile
{
	public FlowerTile(String name)
	{
		//setToolTipText("name");
		super(name);
	}
}